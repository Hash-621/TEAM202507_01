package com.example.NEXTITPROJECTS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextitprojectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NextitprojectsApplication.class, args);
	}

}
