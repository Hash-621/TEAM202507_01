package com.example.NEXTITPROJECTS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NextitprojectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
